package edu.upc.dsa.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;



import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    /*private button boton_0;
    private button boton_1;
    private button boton_2;
    private button boton_3;
    private button boton_4;
    private button boton_5;
    private button boton_6;
    private button boton_7;
    private button boton_8;
    private button boton_9;
    private button boton_clear;
    private button boton_suma;
    private button boton_resta;
    private button boton_division;
    private button boton_multiplicacion;
    private button boton_igual;

    private EditText resultado;*/

   // private EditText resultado;
   private TextView resultado;
    private double operand1 = 0;
    private double operand2 = 0;
    private String currentOperation = "";
    private boolean isNewOperation = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        //-------------------------------------------------------------------------
        resultado = findViewById(R.id.resultado);
        //-------------------------------------------------------------------------
       ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });


        initializeButtons();

    }

    //todos los botones de la pantalla
    private void initializeButtons() {
        Button button0 = findViewById(R.id.boton_0);
        Button button1 = findViewById(R.id.boton_1);
        Button button2 = findViewById(R.id.boton_2);
        Button button3 = findViewById(R.id.boton_3);
        Button button4 = findViewById(R.id.boton_4);
        Button button5 = findViewById(R.id.boton_5);
        Button button6 = findViewById(R.id.boton_6);
        Button button7 = findViewById(R.id.boton_7);
        Button button8 = findViewById(R.id.boton_8);
        Button button9 = findViewById(R.id.boton_9);

        Button buttonsuma = findViewById(R.id.boton_suma);
        Button Buttonresta = findViewById(R.id.boton_menos);
        Button Buttonmultiplicacion = findViewById(R.id.boton_multiplicacion);
        Button Buttondivision = findViewById(R.id.boton_division);

        Button equalButton = findViewById(R.id.boton_igual);
        Button clearButton = findViewById(R.id.boton_clear);

        //Ahora pondre sus eventos

        button0.setOnClickListener(v -> appendNumber("0"));
        button1.setOnClickListener(v -> appendNumber("1"));
        button2.setOnClickListener(v -> appendNumber("2"));
        button3.setOnClickListener(v -> appendNumber("3"));
        button4.setOnClickListener(v -> appendNumber("4"));
        button5.setOnClickListener(v -> appendNumber("5"));
        button6.setOnClickListener(v -> appendNumber("6"));
        button7.setOnClickListener(v -> appendNumber("7"));
        button8.setOnClickListener(v -> appendNumber("8"));
        button9.setOnClickListener(v -> appendNumber("9"));

        buttonsuma.setOnClickListener(v -> setOperation("+"));
        Buttonresta.setOnClickListener(v -> setOperation("-"));
        Buttonmultiplicacion.setOnClickListener(v -> setOperation("*"));
        Buttondivision.setOnClickListener(v -> setOperation("/"));

        equalButton.setOnClickListener(v -> calculador_resultado());
        clearButton.setOnClickListener(v -> clear());
    }

    private void calculador_resultado() {

        if (currentOperation.isEmpty()) {
            return; // Si no hay operación, no hacer nada
        }

        operand2 = Double.parseDouble(resultado.getText().toString());
        double result = 0;

        switch (currentOperation) {
            case "+":
                result = operand1 + operand2;
                break;
            case "-":
                result = operand1 - operand2;
                break;
            case "*":
                result = operand1 * operand2;
                break;
            case "/":
                if (operand2 != 0) {
                    result = operand1 / operand2;
                } else {
                    resultado.setText("Error"); // Evitar división por cero
                    return;
                }
                break;


        }


        resultado.setText(String.valueOf(result)); // Mostrar el resultado
        operand1 = result; // Almacenar el resultado como el nuevo operando
        currentOperation = ""; // Limpiar la operación actual
        isNewOperation = true; // Preparar para la próxima entrada

    }

    private void setOperation(String operacion)
    {

        if (!currentOperation.isEmpty()) {
            calculador_resultado(); // Si ya hay una operación en curso, calcular el resultado antes de la nueva operación
        }
        operand1 = Double.parseDouble(resultado.getText().toString());
        currentOperation = operacion;
        isNewOperation = true; // Indicar que se está iniciando una nueva operación


    }

    private void appendNumber(String number)
    {



        if (isNewOperation) {
            resultado.setText(""); // Limpiar si es una nueva operación
            isNewOperation = false;
        }
        String currentText = resultado.getText().toString();
        resultado.setText(currentText + number);


    }

    private void clear()
    {

        resultado.setText("");
        operand1 = 0;
        operand2 = 0;
        currentOperation = "";
        isNewOperation = false;


    }
}